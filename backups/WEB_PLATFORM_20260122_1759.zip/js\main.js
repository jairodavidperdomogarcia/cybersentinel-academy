// Easter Egg para Hackers Éticos
console.log(
    "%c🛡️ CyberEcosystem Security Protocol Initiated",
    "color: #00B4D8; font-family: monospace; font-size: 16px; font-weight: bold;"
);
console.log(
    "%c¿Buscas vulnerabilidades? Recuerda reportarlas en nuestro programa de Bug Bounty. Happy Hacking! 🕵️‍♂️",
    "color: #A0AEC0; font-family: monospace;"
);

// Mobile Menu Toggle
document.querySelector('.mobile-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Ticker Expand (Mobile)
document.querySelector('.hero-ticker').addEventListener('click', function() {
    if(window.innerWidth <= 768) {
        this.classList.toggle('expanded');
        // Optional: Add CSS for .expanded if needed, or just let it wrap naturally
        this.style.height = this.classList.contains('expanded') ? 'auto' : 'initial';
        this.style.whiteSpace = this.classList.contains('expanded') ? 'normal' : 'nowrap';
    }
});

// Search Input Animation
const searchInput = document.querySelector('.search-input');
const placeholders = [
    "¿Qué necesitas hoy? (empleo...)",
    "¿Qué necesitas hoy? (experto...)",
    "¿Qué necesitas hoy? (alerta...)",
    "¿Qué necesitas hoy? (curso...)"
];
let placeholderIndex = 0;

setInterval(() => {
    placeholderIndex = (placeholderIndex + 1) % placeholders.length;
    searchInput.setAttribute('placeholder', placeholders[placeholderIndex]);
}, 3000);

// Navbar Scroll Effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Performance Metrics Monitor
document.addEventListener('DOMContentLoaded', () => {
    // Track tiempo de carga
    const loadTime = window.performance.timing.domContentLoadedEventEnd - 
                    window.performance.timing.navigationStart;
    console.log(`🚀 Página cargada en ${loadTime}ms`);
    
    // Si es mayor a 2s, considerar optimizaciones
    if (loadTime > 2000) {
        console.warn('⚠️ Considerar optimizar assets para mejor performance');
    }
});

